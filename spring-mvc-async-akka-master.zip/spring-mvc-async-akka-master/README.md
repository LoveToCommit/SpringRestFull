spring-mvc-async-akka
=====================

Example Java web app demonstrating how to implement a Spring asynchronous REST API that interacts with Akka
