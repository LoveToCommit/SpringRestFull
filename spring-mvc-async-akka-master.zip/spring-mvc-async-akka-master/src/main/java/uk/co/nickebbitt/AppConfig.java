/*
 * $Header: $
 */

package uk.co.nickebbitt;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

/**
 *
 * @author Nick Ebbitt
 */
@Configuration
@EnableWebMvc
public class AppConfig {

}
